<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>Le tableau des scores</title>
</head>
<body>
    <div class="container">
        <?php
        /**
         * Avant de commencer :
         * 1. Importez le fichier cpweb_mysql_1.sql dans phpMyAdmin. (Cela crée la base `cpweb_mysql_1`)
         */

        $estConnecte = false;

        //Si on reçoit des données en POST 
        if(count($_POST)){
            
            //@TODO on cherche l'utilisateur correspondant aux identifiant et mot de passe fournis

                //@TODO s'il n'existe pas on affiche un message d'erreur

                //@TODO s'il existe, on passe la variable $estConnecte à true;

        }

        //si l'utilisateur est connecté
        if($estConnecte){
            //@TODO on affiche un message de bienvenue qui contient le nom Réel de l'utilisateur.

        }else{
            //sinon on affiche le formulaire de connexion
            ?>
            <h1>Connexion</h1>
            <form action="" method="POST">
                <input type="text" name="username" placeholder="Identifiant">
                <input type="password" name="password" placeholder="Mot de passe">
                <input type="submit" value="Envoyer">
            </form>
            <?php
        }
        ?>

        <?php
        //si l'utilisateur est connecté
        if($estConnecte){

            //on récupère les scores et on les affiche dans un tableau
            //pour la déco voir : https://getbootstrap.com/docs/5.2/content/tables/
                
            //bonus : on affiche la ligne du joueur connecté dans une couleur différente.
        }
        ?>
    </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
</body>
</html>
<?php
//ICI je range mes fonctions.

/**
 * Retourne l'utilisateur si les infos fournies sont correctes
 * Sinon retourne false
 * @param String $username : nom d'utilisateur
 * @param String $password : mot de passe en clair
 * @return bool|array Les informations de l'utilisateur ou false s'il n'existe pas.
 */
function recupererCompteUtilisateur($username, $password){

    $connection = connexionMysql();

    $query = "SELECT * FROM users ".
    "WHERE username = '". mysqli_real_escape_string($connection, $username)."' ".
    "AND password = '". mysqli_real_escape_string($connection, $password)."' ";

    $result = mysqli_query($connection, $query);
    if($result->num_rows != 1){
        return false;
    }

    //converti la première ligne de résultat en un tableau PHP
    return $result->fetch_array(); 

}

/**
 * Retourne le tableau des scores
 * @return array un tableau contenant la liste des scores. Chaque ligne de score est un tableau associatif.
 */
function recupererScores(){

    $connection = connexionMysql();

    $query = "SELECT username, realName, score FROM users ORDER BY score DESC";

    $result = mysqli_query($connection, $query);
    
    //retourne tous les résultats sous forme de tableau
    return $result->fetch_all(MYSQLI_ASSOC); 

}

function connexionMysql(){
    $connexion = new mysqli("localhost", "root", "", "cpweb_mysql_1");
    if(!$connexion){
        die("Impossible de se connecter à la base MySQL.");
    }
    return $connexion;
}
?>