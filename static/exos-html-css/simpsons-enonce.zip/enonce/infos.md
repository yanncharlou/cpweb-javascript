Objectif :
Intégrer la page.

# Tailles importantes :
La colonne générale fait 1000px de large.

# Couleurs utilisées :
Jaune : #FFD304
Bleu foncé : #1F2A60

# Police par défaut pour les textes : 
'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;

# Polices "genre comics" : 
"Gochi Hand" de fonts.google.com


# Liens du menu principal
Pas la peine de faire les autres pages.
Les liens deviennent jaunes au survol de la souris.

La famille -> famille.html
La ville -> ville.html
Contactez la famille -> contact.html

# Articles
Boutons "En savoir plus" faire simplement des liens vers "#".

# Pied de page
Lien instagram qui s'ouvre dans un nouvel onglet : https//www.instagram.com/hidreley/?hl=fr
Lien wikipedia qui s'ouvre dans un nouvel onglet : https://fr.wikipedia.org/wiki/Les_Simpson

Crédit des icônes : 
Icons made by <a href="https://www.freepik.com" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a>