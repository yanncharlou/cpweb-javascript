# Objectif :
Intégrer deux pages : 
- Page d'accueil : index.html
- Page de contact : contact.html

# Informations communes aux deux pages

## Tailles importantes :
La colonne générale fait 1140px de large.

## Couleurs utilisées :
Rouge : #cc3030
Noir : black
Blanc : white

## Polices :
La police "genre comics" : cursive
La police "carrée" : sans-serif
Il s'agit de noms standards de police. Pas la peine de les installer depuis google fonts ou autre.

## Entête :
Le logo fait 300px de large.
Tous les liens mènent vers index.html sauf Contact qui mène vers contact.html
Les liens deviennent rouges au survol de la souris.

### Texte
Films
Extraits vidéo
Glossaire 
Interviews 
Contact 

## Pied de page
Tous les liens mènent vers https://www.nanarland.com .
Les liens deviennent noirs au survol de la souris.


# Page d'accueil (index.html)

Le titre de la page (ouglet du navigateur) est : Accueil Nanarland

## Bloc introduction
Le bouton "lire la suite" mène vers https://www.nanarland.com .

### Texte : 
Réalisateur visionnaire incompris ou gourou complètement perché ? Notre bio Neil Breen se penche sur l'homme et son œuvre hors normes. 

## Bloc films
Chaque colonne fait 210px de large.
Il n'y a pas de lien.

### Texte
APEX - Note : 2/5
L'Avion de l'Apocalypse - Note : 2/5
Stargrove et Danja, agents exécutifs - Note : 4/5
Haseena Atom Bomb - Note : 5/5
La Nuit du Risque - Note : 4/5

# Page contact (contact.html)

Le titre de la page (ouglet du navigateur) est : Contactez Nanarland

## Formulaire
Le formulaire envoie ses informations vers https://bulle.me/sud-management/html-css/testformulaire.php avec la méthode POST.
Le sujet est un choix multiple entre les options suivantes :

Texte : Proposer un nanard
Valeur : film

Texte : Faire un commentaire
Valeur : comment

# Questions et assistance
sur le forum discord https://discord.gg/fPnzHVksag ou par mail à perso@yanncharlou.fr .